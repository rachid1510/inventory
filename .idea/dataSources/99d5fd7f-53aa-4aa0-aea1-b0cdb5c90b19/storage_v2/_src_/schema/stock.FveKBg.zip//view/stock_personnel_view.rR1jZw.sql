CREATE VIEW stock_personnel_view AS
  SELECT
    `p`.`id`                                                              AS `id`,
    `p`.`first_name`                                                      AS `first_name`,
    `p`.`last_name`                                                       AS `last_name`,
    `p`.`phone_number`                                                    AS `phone_number`,
    `p`.`created_at`                                                      AS `created_at`,
    `p`.`updated_at`                                                      AS `updated_at`,
    `p`.`fonction`                                                        AS `fonction`,
    (SELECT count(0)
     FROM ((`stock`.`inventory_personals` `ip`
       JOIN `stock`.`products` `pr` ON ((`pr`.`id` = `ip`.`personal_id`))) JOIN `stock`.`movements` `m`
         ON ((`m`.`id` = `pr`.`movement_id`)))
     WHERE ((`m`.`category_id` = 1) AND (`ip`.`personal_id` = `p`.`id`))) AS `nombreboitier`,
    (SELECT count(0)
     FROM ((`stock`.`inventory_personals` `ip`
       JOIN `stock`.`products` `pr` ON ((`pr`.`id` = `ip`.`personal_id`))) JOIN `stock`.`movements` `m`
         ON ((`m`.`id` = `pr`.`movement_id`)))
     WHERE ((`m`.`category_id` = 2) AND (`ip`.`personal_id` = `p`.`id`))) AS `nombregsm`
  FROM `stock`.`personals` `p`;

